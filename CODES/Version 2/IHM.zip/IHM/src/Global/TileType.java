package Global;

// Enum�ration des types de case : vide, obstacle et checkpoint, mutuellement exclusifs
public enum TileType {EMPTY, OBSTACLE, CHECKPOINT}

package Global;

import java.util.LinkedList;

import Astar.Astar;
import Astar.AstarTile;
import Graphics.LocalGraphics;

// Classe a executer pour faire une simulation
public class PathFinder {
	
	// Dimensions en cases de la grille
	public static int n = 100;
	public static int m = 100;
	
	// Dimensions en pixels de la grille
	public static int frameWidth = 1000;
	public static int frameHeight = 1000;
	
	// Donn�es graphiques
	public static int graphicRefreshPerPathRefresh = 10; /* Nombre de refresh graphiques avant un calcul complet des chemins */
	public static int frameDuration = 100; /* D�lai de rafraichissement graphique */
	
	//Grille
	public static Grid grid;
	
	// Graphique
	public static LocalGraphics localGraphics;
	
	// Fcontion main, a exectuer pour obtenir la simulation
	public static void main(String[] args) {
		 
		long tStart = 0;
		long tEnd = 0;
		
		init();
		try { 
			/* Boucle d'affichage */
			while (localGraphics.frame.isVisible()) {
				System.out.println("Frame");
				for (int i = 0 ; i < graphicRefreshPerPathRefresh ; i++) {
					tStart = System.currentTimeMillis();
					refreshGraphics();
					refreshEnnemy();
					tEnd = System.currentTimeMillis();
					if (tEnd - tStart < frameDuration) {
						Thread.sleep(frameDuration - (tEnd - tStart));
					}
				}
				if (grid.pathHasChanged) {
					refreshPath();
				}
			}
		}
		catch (InterruptedException e){
			localGraphics.refreshGraphics();
			System.out.println(e.getMessage());
		}
	}
	
	// Met � jour les graphiques
	public static void refreshGraphics() {
		localGraphics.refreshGraphics();
	}

	public static void refreshEnnemy() {
		for (Ennemy ennemy : grid.ennemies) {
			ennemy.refresh();
		}
	}
	
	// Trouve le chemin entre le checkpoint i et i+1. Si i le dernier indice de checkpoints, entre i et 0
	public static LinkedList<Tile> intermediatePathFinder(Tile startTile, Tile endTile) {
		AstarTile astarStartTile = new AstarTile(startTile);
		AstarTile astarEndTile = new AstarTile(endTile);
		LinkedList<AstarTile> astarResult = Astar.aStar(grid, astarStartTile, astarEndTile);
		LinkedList<Tile> result = new LinkedList<Tile>();
		if (astarResult == null) {
			grid.pathReady = false;
			System.out.println("Pas de chemin trouv�");
			return null;
		}
		for (AstarTile e : astarResult) {
			result.add((Tile)e);
		}
		grid.pathReady = true;
		return result;
	}
	
	// Trouve le chemin qui relie tous les checkpoints
	public static LinkedList<Tile> pathFinder() {
		
		int numberOfCheckpoints = grid.checkpoints.size();
		
		if (numberOfCheckpoints < 2) {
			grid.pathReady = false;
			return new LinkedList<Tile>();
		}
		
		LinkedList<Tile> result = new LinkedList<Tile>();
		LinkedList<Tile> intermediateResult;
		for (int i = 0 ; i < numberOfCheckpoints - 1; i++) {
			intermediateResult = intermediatePathFinder(grid.checkpoints.get(i), grid.checkpoints.get(i + 1));
			if (intermediateResult == null) return new LinkedList<Tile>();
			result.addAll(intermediateResult);

		}
		intermediateResult = intermediatePathFinder(grid.checkpoints.get(numberOfCheckpoints - 1), grid.checkpoints.get(0));
		if (intermediateResult == null) return new LinkedList<Tile>();
		result.addAll(intermediateResult);
		return result;
	}
	
	// Met � jour le chemin qui relie les checkpoints
	public static void refreshPath() {
		grid.path = pathFinder();
		localGraphics.refreshGraphicsPath();
	}
	
	// Initialise toutes les variables
	public static void init() {
		grid = new Grid(n, m);
		initGraphics();
		initDrones();
		initObstacles();
		initCheckpoints();
		initEnnemies();
		initPath();
		refreshGraphics();
	}
	
	// Initialise les graphiques
	public static void initGraphics() {
		localGraphics = new LocalGraphics(n, m, frameWidth, frameHeight, grid);
	}
	
	// Initialise le chemin
	public static void initPath()  {
		grid.path = pathFinder();
	}
	
	// Initialise les drones
	public static void initDrones() {
		addDrone(0, 0);
	}
	
	// Initialise les obstacles
	public static void initObstacles() {
		addObstacle(1, 1);
	}
	
	// Initialise les checkpoints
	public static void initCheckpoints() {
		addCheckpoint(2, 0);
	}
	
	// Iitialise les ennemis
	public static void initEnnemies() {
		addEnnemy(2, 1);
	}
	
	// Ajoute un drone � la simulation 
	public static void addDrone(int x, int y) {
		grid.toRepaint.remove(grid.grid[x][y]);
		Drone drone = new Drone(x, y);
		grid.grid[x][y] = drone;
		grid.drones.add(drone);
		grid.toRepaint.add(drone);
	}
	
	// Ajoute un obstacle � la simulation 
	public static void addObstacle(int x, int y) {
		grid.toRepaint.remove(grid.grid[x][y]);
		Obstacle obstacle = new Obstacle(x, y);
		grid.grid[x][y] = obstacle;
		grid.obstacles.add(obstacle);
		grid.toRepaint.add(obstacle);
	}
	
	// Ajoute un checkpoint � la simulation 
	public static void addCheckpoint(int x, int y) {
		Tile tile = grid.grid[x][y];
		tile.isCheckpoint = true;
		grid.checkpoints.add(tile);
	}
	
	// Ajoute un ennemi � la simulation 
	public static void addEnnemy(int x, int y) {
		grid.toRepaint.remove(grid.grid[x][y]);
		Ennemy ennemy = new Ennemy(x, y);
		grid.grid[x][y] = ennemy;
		grid.ennemies.add(ennemy);
		grid.toRepaint.add(ennemy);
	}
}

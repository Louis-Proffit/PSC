package Global;

// Enum�ration du contenu d'une case : vide, drone ou ennemi, mutuellement exclusifs
public enum TileContainer {EMPTY, DRONE, ENNEMY}

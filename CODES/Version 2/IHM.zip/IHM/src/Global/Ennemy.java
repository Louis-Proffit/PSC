package Global;

// Objet Ennemis
public class Ennemy extends Tile{
	
	int xTarget;
	int yTarget;
	
	// Constructeur � partir d'une position (x, y)
	public Ennemy(int x, int y) {
		super(x, y);
		xTarget = (int)(Math.random() * PathFinder.n);
		yTarget = (int)(Math.random() * PathFinder.m);
		System.out.println(xTarget + ";" + yTarget);
	}
	
	// Constructeur � partir d'une case
	public Ennemy(Tile tile) {
		super(tile.x, tile.y, tile.isCheckpoint);
		xTarget = (int)(Math.random() * PathFinder.n);
		yTarget = (int)(Math.random() * PathFinder.m);
		System.out.println(xTarget + ";" + yTarget);
	}
	
	@Override
	public void repaint() {
		PathFinder.localGraphics.paintEnnemy(this);
	}
	
	public void refresh() {
		PathFinder.grid.grid[this.x][this.y] = new Tile(this);
		PathFinder.grid.toRepaint.add(PathFinder.grid.grid[this.x][this.y]);
		
		int xPath = this.x - xTarget;
		int yPath = this.y - yTarget;
		int dx = 0;
		int dy = 0;
		if ((xPath > 0) & x < PathFinder.n  - 1) {
			dx = -1;
		}
		if ((xPath < 0) & x > 1) {
			dx = +1;
		}
		if ((yPath > 0) & y < PathFinder.m  - 1) {
			dy = -1;
		}
		if ((yPath < 0) & y > 1) {
			dy = +1;
		}
		this.x += dx;
		this.y += dy;
		PathFinder.grid.grid[this.x][this.y] = this;
		PathFinder.grid.toRepaint.add(this);
	}
}

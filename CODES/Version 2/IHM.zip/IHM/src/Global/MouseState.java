package Global;

// Liste des �tats possibles, s�l�ctionn�s au clavie, pour la souris. Conditionne l'action � effectuer sur la prochaine tuile cliqu�e
public enum MouseState {EMPTY, DRONE, OBSTACLE, CHECKPOINT, ENNEMY}

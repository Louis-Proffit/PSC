package Global;

// Objet Ennemis
public class Ennemy {

}

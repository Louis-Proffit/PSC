package Global;

// Objet drone
public class Drone {
	
	// Position
	public int x;
	public int y;
	
	// Constructeur � partir d'une position (x, y)
	public Drone(int x, int y){
		this.x = x;
		this.y = y;
	}
}